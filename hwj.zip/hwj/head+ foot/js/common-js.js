
// 导航栏特效
    // $(window).load( function () {

    // })
    $(function(){
        $(".nav>ul>li").mouseover(function(){
            var index = $(this).index();
            $(this).children("a").css("color","#1e569d").show(1000)
            $(this).find('div').stop().show(300)
            
        })
        $(".nav>ul>li").mouseout(function(){
            var index = $(this).index();
            $(this).children("a").css("color","black").show(1000)
            $(this).find('div').stop().hide(300)
           
        })
    })